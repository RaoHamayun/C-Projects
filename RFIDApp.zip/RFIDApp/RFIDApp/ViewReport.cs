﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace RFIDApp
{
    public partial class ViewReport : Form
    {
        private SqlConnection xConn;
        public ViewReport()
        {
            InitializeComponent();
            xConn = new SqlConnection("Server=.; DataBase=AttendanceDB; UID=sa; PWD=123;");
            ShowReport();
        }
        private void ShowReport()
        {
            DataTable xTable = new DataTable();
            new SqlDataAdapter("Select * from tblAttendance order by AID DESC", xConn).Fill(xTable);
            xGrid.DataSource = xTable;
            xGrid.Columns[0].Width = 50;
            xGrid.Columns[1].Width = 50;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text.Equals("All"))
            {
                ShowReport();
            }
            else
            {
                DataTable xTable = new DataTable();
                new SqlDataAdapter("Select * from tblAttendance Where FullName='" + comboBox1.Text + "'", xConn).Fill(xTable);
                xGrid.DataSource = xTable;
                xGrid.Columns[0].Width = 50;
                xGrid.Columns[1].Width = 50;
            }
        }
    }
}
