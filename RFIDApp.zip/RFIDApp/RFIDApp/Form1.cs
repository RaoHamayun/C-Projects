﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace RFIDApp
{
    public partial class Form1 : Form
    {
        private SqlConnection xConn;
        private string EID, Status;
        public Form1()
        {
            InitializeComponent();
            xConn = new SqlConnection("Server=.; DataBase=AttendanceDB; UID=sa; PWD=123;");
            EID = Status = null;
        }

        private void txtRFID_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                DataTable xTable = new DataTable();
                new SqlDataAdapter("Select * from tblEmployees Where RFID='" + txtRFID.Text + "'", xConn).Fill(xTable);
                EID = xTable.Rows[0][0].ToString();
                lblRFID.Text = xTable.Rows[0][1].ToString();
                lblName.Text = xTable.Rows[0][2].ToString();
                lblPhone.Text = xTable.Rows[0][3].ToString();
                lblEmail.Text = xTable.Rows[0][4].ToString();
                PicBox.Load("Pics//" + EID + ".jpg");
                txtRFID.Text = null;
                txtRFID.Focus();
                
                if (lstEmp.Items.Contains(lblName.Text))
                {
                    lstEmp.Items.Remove(lblName.Text);
                    Status = "Time-OUT";
                }
                else
                {
                    lstEmp.Items.Add(lblName.Text);
                    Status = "Time-IN";
                }
                xConn.Open();
                new SqlCommand("Insert into tblAttendance values ('" + EID + "','" + lblName.Text + "','" + DateTime.Now.ToString("dd-MMM-yyyy") + "','" + DateTime.Now.ToString("HH:mm:ss") + "','"+Status+"')", xConn).ExecuteNonQuery();
                xConn.Close();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            new ViewReport().Show();
        }        
    }
}
