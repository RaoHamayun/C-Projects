create dataBAse AttendanceDB;
Use AttendanceDB;

Create table tblEmployees
(
EID int identity(100,1) primary key,
RFID varchar(15) Unique,
FullName varchar(50),
PhoneNo  varchar(15) unique,
Email    varchar(50) unique
);
Insert into tblEmployees values ('0007739737','Farooq','0332-1234567','Farooq@yahoo.com');
Insert into tblEmployees values ('0001868249','Salman','0332-1234568','Salman@yahoo.com');
Insert into tblEmployees values ('0000598402','Faisal','0332-1234569','Faisal@yahoo.com');
Insert into tblEmployees values ('0001875402','Hassan','0332-1234570','Hassan@yahoo.com');
Select * from tblEmployees;
----------------------------------
Create table tblAttendance
(
AID int identity(1,1) primary key,
EID int,
FullName varchar(50),
AttDate  varchar(15),
AttTime  varchar(15),
Status   varchar(15)
);
Select * from tblAttendance order by AID DESC;