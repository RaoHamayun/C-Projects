﻿using System;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace TimeLogicApp
{
    public partial class Form1 : Form
    {
        private SqlConnection con;
        private TimeSpan T0,T1,T2,T3;
        private string Status;
        public Form1()
        {
            InitializeComponent();
             T0 = new TimeSpan(8, 0, 0);
            Status = null;
            con = new SqlConnection("Server=.;Database=master;UID=sa;PWD=123");
            ShowData();

        }
        private void ShowData() 
        {
            DataTable xTable = new DataTable();
            new SqlDataAdapter("select * from tblTimeLogic", con).Fill(xTable);
            xGrid.DataSource = xTable;   
        }
        private void btnCalc_Click(object sender, EventArgs e)
        {
            String t2 = DateTime.Now.ToString("hh:mm:ss");
            T2 = TimeSpan.Parse(t2);
            T3 = T2 - T1;
            txtWHours.Text = T3.ToString();
            double D = 500.0 / 60.0;            
            int PerMinute = (int)Math.Ceiling(D);
            this.Text = PerMinute.ToString();
            int Wedge = (500 * T3.Hours) + (T3.Minutes * PerMinute);
            //--------------------------------------//
            
            //--------------------------------------//
            con.Open();
            new SqlCommand("update tblTimeLogic set TimeOUT = '"+t2+"',WHours='"+T3.ToString()+"',wedge = '"+Wedge.ToString()+"' where TID = '"+txtTimeOUT.Text+"'", con).ExecuteNonQuery();
            con.Close();
            ShowData();
            

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnin_Click(object sender, EventArgs e)
        {
            String t1 = DateTime.Now.ToString("hh:mm:ss");
            T1 = TimeSpan.Parse(t1);
            if (T1 > T0)
            { Status = "Late-IN"; }
            else if (T1 < T0)
            { Status = "Early-IN"; }
            else
            { Status = "On-Time"; }
            con.Open();
            new SqlCommand("insert into tbltimeLogic(Full_Name,OfficeTime,TimeIn,Status) values('"+txtTimeIN.Text+"','" + T0.ToString() + "','" + T1 + "','" + Status + "')", con).ExecuteNonQuery();
            con.Close();
            ShowData();
        }
    }
}
